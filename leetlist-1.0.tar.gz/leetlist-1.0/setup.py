from distutils.core import setup 

setup(name='leetlist', 
	version='1.0',
	description='Leetlist', 
	author='Matthew "Radical_Ronin" Harvey, Mike "Stockho1m" Mahaffey', 
	py_modules=['leetlist'])
